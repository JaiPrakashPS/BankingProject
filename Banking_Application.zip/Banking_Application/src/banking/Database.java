package banking;
import java.sql.*;
public class Database {
	private Connection connection;
	public Database() {
		try {
			connection  = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank", "root", "jai1466@1");
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public void insertAccount(Account account) {
		String sql = "INSERT INTO Accounts (account_id,customer_id,name,phone_number,address,account_type,balance,created_at");
		
}
