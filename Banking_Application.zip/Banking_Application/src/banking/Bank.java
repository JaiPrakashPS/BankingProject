package banking;
import java.util.ArrayList;
import java.util.*;
public class Bank {
	private ArrayList<Account> accounts;
	private Scanner scanner;
	private Database database;
	
	public Bank(){
		accounts = new ArrayList<>();
		scanner  = new Scanner(System.in);
		database = new Database();
		loadAccountsFromdatabase();
	}
	public void start() {
		while(true) {
			System.out.println("\n --- Welcome to the banking application ---");
			System.out.println("1. Create Account");
			System.out.println("2. Deposit");
			System.out.println("3. Withdraw");
			System.out.println("4. Check Balance");
			System.out.println("5. View Transaction History");
			System.out.println("6. Transfer funds");
			System.out.println("7. Generate reports");
			System.out.println("8. Update");
			System.out.println("9. Exit");
			System.out.println("Choose an option: ");
			int choice = scanner.nextInt();
			switch(choice) {
			case 1:
				createAccount();
				break;
			case 2:
				deposit();
				break;
			case 3:
				withdraw();
				break;
			case 4:
				viewAccount();
			case 5:
				viewTransactionHistory();
				break;
			case 6:
				viewTransferFunds();
				break;
			case 7:
				generateReportsmenu();
				break;
			case 8:
				System.out.println("Enter account ID to update: ");
				int account = scanner.nextInt("System.in");
				updatecustomerDetails(accountId);
				break;
			case 9:
				System.out.println("Thank you for using the Banking application");
				database.closeConnection();
				return;
			default:
				System.out.println("Invalid option try again");
			}
		}
	}
	private void createAccount() {
	    System.out.print("Enter customer ID: ");
	    int customerId = scanner.nextInt();
	    if (String.valueOf(customerId).length() != 5) {
	        System.out.println("Customer ID must be 5 digits.");
	        return;
	    }

	    System.out.print("Enter account type (s for Savings, c for Current): ");
	    char accountTypeInput = scanner.next().charAt(0);
	    String accountType;

	    if (accountTypeInput == 's' || accountTypeInput == 'S') {
	        accountType = "Savings";
	    } else if (accountTypeInput == 'c' || accountTypeInput == 'C') {
	        accountType = "Current";
	    } else {
	        System.out.println("Invalid account type entered. Defaulting to Savings.");
	        accountType = "Savings";
	    }
	    System.out.print("Enter your name: ");
	    String name = scanner.nextLine();

	    System.out.print("Enter your phone number: ");
	    String phoneNumber = scanner.nextLine();
	    if (phoneNumber.length() != 10) {
	        System.out.println("Phone Number must be 10 digits.");
	        return;
	    }

	    System.out.print("Enter your address: ");
	    String address = scanner.nextLine();
	    Account account = new Account(customerId,accountType,name,phoneNumber,address);
	    database.insertAccount(account);
	    System.out.println("Account created successfully! your account ID: "+account.getAccountid());
	    }
	
	private void deposit() {
	    System.out.print("Enter account ID: ");
	    int accountId = scanner.nextInt();

	    Account account = findAccount(accountId);

	    if (account != null) {
	        System.out.print("Enter amount to deposit: ");
	        double amount = scanner.nextDouble();

	        account.deposit(amount);
	        database.updateAccountBalance(account);

	        System.out.println("Deposit successful! New balance: " + account.getBalance());
	    } else {
	        System.out.println("Account not found.");
	    }
	}
	private void withdraw() {
	    System.out.print("Enter account ID: ");
	    int accountId = scanner.nextInt();

	    Account account = findAccount(accountId);

	    if (account != null) {
	        System.out.print("Enter amount to withdraw: ");
	        double amount = scanner.nextDouble();

	        if (account.withdraw(amount)) {
	            database.updateAccountBalance(account);
	            System.out.println("Withdrawal successful! New balance: " + account.getBalance());
	        } else {
	            System.out.println("Insufficient funds.");
	        }
	    } else {
	        System.out.println("Account not found.");
	    }
	}
	private void viewAccount() {
		System.out.println("Enter Account ID:");
		int acccountId = scanner.nextInt();
		Account account = findAccount(acccountId);
		
		if(account != null) {
			System.out.print("Account name "+ account.getName());
			System.out.print("Account Id "+ account.getAccountid());
			System.out.print("Account Address "+ account.getAddress());
			System.out.print("Account Phone_no "+ account.getPhoneNumber());
			System.out.print("Customer Id  "+ account.getCustomerId());
			System.out.print("Customer Id  "+ account.getBalance());
		}
		else {
			System.out.print("Account not found");
		}
	}
	private void viewTransactionHistory() {
		System.out.print("Enter account ID: ");
		int accountId = scanner.nextInt();
		Account account = findAccount (accountId);
		if (account != null) {
		account.printTransactionHistory();
		} else {
		System.out.println("Account not found.");
		}
	}
	private void viewTransferFunds() {
		
	}
}








